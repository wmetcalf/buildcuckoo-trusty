// Install in elasticsearch-x.x.x/config/scripts/ directory (which might need to be created)
ctx._source.count+=1;
ctx._source.lastSeen=lastSeen;
